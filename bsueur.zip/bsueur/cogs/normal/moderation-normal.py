""""
Copyright © Krypton 2022 - https://github.com/kkrypt0nn (https://krypton.ninja)
Description:
This is a template to create your own discord bot in python.

Version: 4.1
"""

import json
import os
import sys

import disnake
from disnake.ext import commands
from disnake.ext.commands import Context

from helpers import checks

if not os.path.isfile("config.json"):
    sys.exit("'config.json' not found! Please add it and try again.")
else:
    with open("config.json") as file:
        config = json.load(file)


class Moderation(commands.Cog, name="moderation-normal"):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(
        name="kick",
        description="Kick a user out of the server.",
    )
    @commands.has_permissions(kick_members=True)
    @checks.not_blacklisted()
    async def kick(self, context: Context, member: disnake.Member, *, reason: str = "Not specified") -> None:
        """
        Kick a user out of the server.
        :param context: The context in which the command has been executed.
        :param member: The member that should be kicked from the server.
        :param reason: The reason for the kick. Default is "Not specified".
        """
        if member.guild_permissions.administrator:
            embed = disnake.Embed(
                title="Ошибка!",
                description="Пользователь имеет права Администратора.",
                color=0xE02B2B
            )
            await context.send(embed=embed)
        else:
            try:
                embed = disnake.Embed(
                    title="Пользователь выгнан!",
                    description=f"**{member}** был выгнан **{context.author}**!",
                    color=0x9C84EF
                )
                embed.add_field(
                    name="Причина:",
                    value=reason
                )
                await context.send(embed=embed)
                try:
                    await member.send(
                        f"Вы были выгнаны **{context.author}**!\nПричина: {reason}"
                    )
                except disnake.Forbidden:
                    # Couldn't send a message in the private messages of the user
                    pass
                await member.kick(reason=reason)
            except:
                embed = disnake.Embed(
                    title="Ошибка!",
                    description="Произошла ошибка при попытке выгнать пользователя, возможно его роль выше моей роли.",
                    color=0xE02B2B
                )
                await context.send(embed=embed)

    @commands.command(
        name="nick",
        description="Изменение ника на сервере.",
    )
    @commands.has_permissions(manage_nicknames=True)
    @checks.not_blacklisted()
    async def nick(self, context: Context, member: disnake.Member, *, nickname: str = None) -> None:
        """
        Change the nickname of a user on a server.
        :param context: The context in which the command has been executed.
        :param member: The member that should have its nickname changed.
        :param nickname: The new nickname of the user. Default is None, which will reset the nickname.
        """
        try:
            await member.edit(nick=nickname)
            embed = disnake.Embed(
                title="Смена имени!",
                description=f"**{member}'s** было изменено на **{nickname}**!",
                color=0x9C84EF
            )
            await context.send(embed=embed)
        except:
            embed = disnake.Embed(
                title="Ошибка!",
                description="Произошла ошибка при попытке смене ника пользователя, возможно его роль выше моей роли.",
                color=0xE02B2B
            )
            await context.send(embed=embed)

    @commands.command(
        name="ban",
        description="Bans a user from the server.",
    )
    @commands.has_permissions(ban_members=True)
    @checks.not_blacklisted()
    async def ban(self, context: Context, member: disnake.Member, *, reason: str = "Not specified") -> None:
        """
        Bans a user from the server.
        :param context: The context in which the command has been executed.
        :param member: The member that should be banned from the server.
        :param reason: The reason for the ban. Default is "Not specified".
        """
        try:
            if member.guild_permissions.administrator:
                embed = disnake.Embed(
                    title="Ошибка!",
                    description="Пользователь имеет права Администратора.",
                    color=0xE02B2B
                )
                await context.send(embed=embed)
            else:
                embed = disnake.Embed(
                    title="User Banned!",
                    description=f"**{member}** was banned by **{context.author}**!",
                    color=0x9C84EF
                )
                embed.add_field(
                    name="Reason:",
                    value=reason
                )
                await context.send(embed=embed)
                try:
                    await member.send(f"You were banned by **{context.author}**!\nReason: {reason}")
                except disnake.Forbidden:
                    # Couldn't send a message in the private messages of the user
                    pass
                await member.ban(reason=reason)
        except:
            embed = disnake.Embed(
                title="Ошибка!",
                description="An error occurred while trying to ban the user. Make sure my role is above the role of the user you want to ban.",
                color=0xE02B2B
            )
            await context.send(embed=embed)

    @commands.command(
        name="warn",
        description="Warns a user in the server.",
    )
    @commands.has_permissions(manage_messages=True)
    @checks.not_blacklisted()
    async def warn(self, context: Context, member: disnake.Member, *, reason: str = "Not specified") -> None:
        """
        Warns a user in his private messages.
        :param context: The context in which the command has been executed.
        :param member: The member that should be warned.
        :param reason: The reason for the warn. Default is "Not specified".
        """
        embed = disnake.Embed(
            title="Выдано предупреждение",
            description=f"**{member}** было выдано предупреждение **{context.author}**!",
            color=0x9C84EF
        )
        embed.add_field(
            name="Причина:",
            value=reason
        )
        await context.send(embed=embed)
        try:
            await member.send(f"Вам было выдано предупреждение **{context.author}**!\nПричина: {reason}")
        except disnake.Forbidden:
            # Couldn't send a message in the private messages of the user
            await context.send(f"{member.mention}, было выдано предупреждение **{context.author}**!\nПричина: {reason}")

    @commands.command(
        name="clear",
        description="Delete a number of messages.",
    )
    @commands.has_guild_permissions(manage_messages=True)
    @checks.not_blacklisted()
    async def purge(self, context: Context, amount: int) -> None:
        """
        Delete a number of messages.
        :param context: The context in which the command has been executed.
        :param amount: The number of messages that should be deleted.
        """
        try:
            amount = int(amount)
        except:
            embed = disnake.Embed(
                title="Ошибка!",
                description=f"`{amount}` неверное кол-во.",
                color=0xE02B2B
            )
            await context.send(embed=embed)
            return
        if amount < 1:
            embed = disnake.Embed(
                title="Ошибка!",
                description=f"`{amount}` неверное кол-во.",
                color=0xE02B2B
            )
            await context.send(embed=embed)
            return
        purged_messages = await context.channel.purge(limit=amount)
        embed = disnake.Embed(
            title="Произведена очистка!",
            description=f"**{context.author}** удалено **{len(purged_messages)}** сообщений!",
            color=0x9C84EF
        )
        await context.send(embed=embed)

    @commands.command(
        name="hackban",
        description="Bans a user without the user having to be in the server."
    )
    async def hackban(self, context: Context, user_id: int, *, reason: str) -> None:
        """
        Bans a user without the user having to be in the server.
        :param context: The context in which the command has been executed.
        :param user_id: The ID of the user that should be banned.
        :param reason: The reason for the ban. Default is "Not specified".
        """
        try:
            await self.bot.http.ban(user_id, context.guild.id, reason=reason)
            user = await self.bot.get_or_fetch_user(user_id)
            embed = disnake.Embed(
                title="Пользователь забанен!",
                description=f"**{user} (ID: {user_id}) ** был забанен **{context.author}**!",
                color=0x9C84EF
            )
            embed.add_field(
                name="Причина:",
                value=reason
            )
            await context.send(embed=embed)
        except:
            embed = disnake.Embed(
                title="Причина!",
                description="Некорректно введены данные.",
                color=0xE02B2B
            )
            await context.send(embed=embed)


def setup(bot):
    bot.add_cog(Moderation(bot))
